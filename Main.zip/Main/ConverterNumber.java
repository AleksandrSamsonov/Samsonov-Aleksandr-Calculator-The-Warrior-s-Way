package Main;

public interface ConverterNumber {
    int convert(String value);

    String reverseConvert(int value);
}