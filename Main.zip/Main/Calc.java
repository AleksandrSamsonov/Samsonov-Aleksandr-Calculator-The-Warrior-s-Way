package Main;

import java.math.BigDecimal;

public interface Calc {
    BigDecimal calc(int num1, int num2, char operation);
}
