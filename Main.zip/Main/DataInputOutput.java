package Main;

public interface DataInputOutput {
    String input();

    void output(String out);
}
